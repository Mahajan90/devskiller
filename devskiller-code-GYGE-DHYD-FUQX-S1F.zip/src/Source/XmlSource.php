<?php

declare(strict_types=1);

namespace App\Source;

use Exception;
use SimpleXMLElement;
use App\Service\Source;

class XmlSource implements Source
{
    public function __construct(private string $filePath)
    {
    }

    public function extract(): array
    {
        /** @todo */

        return [];
    }
}
