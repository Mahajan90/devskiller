<?php

declare(strict_types=1);

namespace App\Exception;

use Exception;

class UnsupportedFormatException extends Exception
{
    protected $message = 'Format Not Supported.';
}
