<?php

declare(strict_types=1);

namespace App\Service;

use App\Exception\UnsupportedFormatException;

class MovieService implements Export
{
    private const DEFAULT_SEPARATOR = ',';

    public function __construct(private string $separator = self::DEFAULT_SEPARATOR)
    {
    }

    public function export(Source $source, string $format): string
    {
        /** @todo */
        $movies = $source->getData();
        if($format === 'csv'){
            return $this->convertToCsv($movies);
        }
        throw new UnsupportedFormatException("Format '$format' is not supported.");

    }
}
