<?php

declare(strict_types=1);

namespace App\Service;

interface Source
{
    public function extract(): array;
}
