<?php

/**
 * Project structure test, generated automatically. DO NOT MODIFY.
 *
 * @noinspection ALL
 */
declare(strict_types=1);

namespace tests\structure;

use ReflectionClass;
use ReflectionType;

class StructureTest extends \PHPUnit\Framework\TestCase
{
    public function testStructure()
    {
        $this->assertTrue(\class_exists(base64_decode('QXBwXFNvdXJjZVxYbWxTb3VyY2U=')), base64_decode('Q2xhc3MgJ0FwcFxTb3VyY2VcWG1sU291cmNlJyBkb2VzIG5vdCBleGlzdC4='));
        $class = new ReflectionClass(base64_decode('QXBwXFNvdXJjZVxYbWxTb3VyY2U='));
        $this->assertFalse($class->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNvdXJjZVxYbWxTb3VyY2UgaXMgYWJzdHJhY3Qu'));
        $this->assertFalse($class->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNvdXJjZVxYbWxTb3VyY2UgaXMgZmluYWwu'));
        $this->assertTrue($class->implementsInterface(base64_decode('QXBwXFNlcnZpY2VcU291cmNl')), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNvdXJjZVxYbWxTb3VyY2UgZG9lcyBub3QgaW1wbGVtZW50IGludGVyZmFjZSBBcHBcU2VydmljZVxTb3VyY2Uu'));
        $this->assertTrue($class->isInstantiable(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNvdXJjZVxYbWxTb3VyY2UgaXMgbm90IGluc3RhbnRpYWJsZS4='));

        $this->assertTrue($class->hasMethod(base64_decode('X19jb25zdHJ1Y3Q=')), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIF9fY29uc3RydWN0IG5vdCBmb3VuZCBpbiBjbGFzcyBBcHBcU291cmNlXFhtbFNvdXJjZQ=='));
        $method = $class->getMethod(base64_decode('X19jb25zdHJ1Y3Q='));
        $this->assertTrue($method->isPublic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpfX2NvbnN0cnVjdCgpIGlzIG5vdCBwdWJsaWMu'));
        $this->assertFalse($method->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpfX2NvbnN0cnVjdCgpIGlzIGFic3RyYWN0Lg=='));
        $this->assertFalse($method->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpfX2NvbnN0cnVjdCgpIGlzIGZpbmFsLg=='));
        $this->assertFalse($method->isStatic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpfX2NvbnN0cnVjdCgpIGlzIHN0YXRpYy4='));
        $this->assertEquals(1, $method->getNumberOfRequiredParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpfX2NvbnN0cnVjdCgpIGhhcyBpbnZhbGlkIG51bWJlciBvZiByZXF1aXJlZCBwYXJhbWV0ZXJzLg=='));
        $this->assertGreaterThanOrEqual(1, $method->getNumberOfParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpfX2NvbnN0cnVjdCgpIGhhcyBpbnZhbGlkIG51bWJlciBvZiBwYXJhbWV0ZXJzLg=='));
        $this->assertNull($this->getType($method->getReturnType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpfX2NvbnN0cnVjdCgpIGhhcyBpbnZhbGlkIHJldHVybiB0eXBlLg=='));
    
        $param0 = $method->getParameters()[0];
        $this->assertSame(base64_decode('ZmlsZVBhdGg='), $param0->getName(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICMwIG9mIG1ldGhvZCBBcHBcU291cmNlXFhtbFNvdXJjZTo6X19jb25zdHJ1Y3QoKSBoYXMgaW52YWxpZCBuYW1lLg=='));
        $this->assertSame(base64_decode('c3RyaW5n'), $this->getType($param0->getType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRmaWxlUGF0aCBvZiBtZXRob2QgQXBwXFNvdXJjZVxYbWxTb3VyY2U6Ol9fY29uc3RydWN0KCkgaGFzIGludmFsaWQgdHlwZS4='));
        $this->assertFalse($param0->allowsNull(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRmaWxlUGF0aCBvZiBtZXRob2QgQXBwXFNvdXJjZVxYbWxTb3VyY2U6Ol9fY29uc3RydWN0KCkgYWxsb3dzIG51bGwu'));    

        $this->assertTrue($class->hasMethod(base64_decode('ZXh0cmFjdA==')), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIGV4dHJhY3Qgbm90IGZvdW5kIGluIGNsYXNzIEFwcFxTb3VyY2VcWG1sU291cmNl'));
        $method = $class->getMethod(base64_decode('ZXh0cmFjdA=='));
        $this->assertTrue($method->isPublic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpleHRyYWN0KCkgaXMgbm90IHB1YmxpYy4='));
        $this->assertFalse($method->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpleHRyYWN0KCkgaXMgYWJzdHJhY3Qu'));
        $this->assertFalse($method->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpleHRyYWN0KCkgaXMgZmluYWwu'));
        $this->assertFalse($method->isStatic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpleHRyYWN0KCkgaXMgc3RhdGljLg=='));
        $this->assertEquals(0, $method->getNumberOfRequiredParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpleHRyYWN0KCkgaGFzIGludmFsaWQgbnVtYmVyIG9mIHJlcXVpcmVkIHBhcmFtZXRlcnMu'));
        $this->assertGreaterThanOrEqual(0, $method->getNumberOfParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpleHRyYWN0KCkgaGFzIGludmFsaWQgbnVtYmVyIG9mIHBhcmFtZXRlcnMu'));
        $this->assertSame(base64_decode('YXJyYXk='), $this->getType($method->getReturnType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTb3VyY2VcWG1sU291cmNlOjpleHRyYWN0KCkgaGFzIGludmFsaWQgcmV0dXJuIHR5cGUu'));    

        $this->assertTrue(\class_exists(base64_decode('QXBwXFNlcnZpY2VcTW92aWVTZXJ2aWNl')), base64_decode('Q2xhc3MgJ0FwcFxTZXJ2aWNlXE1vdmllU2VydmljZScgZG9lcyBub3QgZXhpc3Qu'));
        $class = new ReflectionClass(base64_decode('QXBwXFNlcnZpY2VcTW92aWVTZXJ2aWNl'));
        $this->assertFalse($class->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNlcnZpY2VcTW92aWVTZXJ2aWNlIGlzIGFic3RyYWN0Lg=='));
        $this->assertFalse($class->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNlcnZpY2VcTW92aWVTZXJ2aWNlIGlzIGZpbmFsLg=='));
        $this->assertTrue($class->implementsInterface(base64_decode('QXBwXFNlcnZpY2VcRXhwb3J0')), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNlcnZpY2VcTW92aWVTZXJ2aWNlIGRvZXMgbm90IGltcGxlbWVudCBpbnRlcmZhY2UgQXBwXFNlcnZpY2VcRXhwb3J0Lg=='));
        $this->assertTrue($class->isInstantiable(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNlcnZpY2VcTW92aWVTZXJ2aWNlIGlzIG5vdCBpbnN0YW50aWFibGUu'));

        $this->assertTrue($class->hasMethod(base64_decode('X19jb25zdHJ1Y3Q=')), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIF9fY29uc3RydWN0IG5vdCBmb3VuZCBpbiBjbGFzcyBBcHBcU2VydmljZVxNb3ZpZVNlcnZpY2U='));
        $method = $class->getMethod(base64_decode('X19jb25zdHJ1Y3Q='));
        $this->assertTrue($method->isPublic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBpcyBub3QgcHVibGljLg=='));
        $this->assertFalse($method->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBpcyBhYnN0cmFjdC4='));
        $this->assertFalse($method->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBpcyBmaW5hbC4='));
        $this->assertFalse($method->isStatic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBpcyBzdGF0aWMu'));
        $this->assertEquals(0, $method->getNumberOfRequiredParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBoYXMgaW52YWxpZCBudW1iZXIgb2YgcmVxdWlyZWQgcGFyYW1ldGVycy4='));
        $this->assertGreaterThanOrEqual(1, $method->getNumberOfParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBoYXMgaW52YWxpZCBudW1iZXIgb2YgcGFyYW1ldGVycy4='));
        $this->assertNull($this->getType($method->getReturnType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBoYXMgaW52YWxpZCByZXR1cm4gdHlwZS4='));
    
        $param0 = $method->getParameters()[0];
        $this->assertSame(base64_decode('c2VwYXJhdG9y'), $param0->getName(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICMwIG9mIG1ldGhvZCBBcHBcU2VydmljZVxNb3ZpZVNlcnZpY2U6Ol9fY29uc3RydWN0KCkgaGFzIGludmFsaWQgbmFtZS4='));
        $this->assertSame(base64_decode('c3RyaW5n'), $this->getType($param0->getType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRzZXBhcmF0b3Igb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBoYXMgaW52YWxpZCB0eXBlLg=='));
        $this->assertFalse($param0->allowsNull(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRzZXBhcmF0b3Igb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBhbGxvd3MgbnVsbC4='));
        $this->assertTrue($param0->isDefaultValueAvailable(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRzZXBhcmF0b3Igb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBkb2VzIG5vdCBoYXZlIGRlZmF1bHQgdmFsdWUu'));
        $this->assertEquals(',', $param0->getDefaultValue(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRzZXBhcmF0b3Igb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6X19jb25zdHJ1Y3QoKSBoYXMgaW52YWxpZCBkZWZhdWx0IHZhbHVlLg=='));    

        $this->assertTrue($class->hasMethod(base64_decode('ZXhwb3J0')), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIGV4cG9ydCBub3QgZm91bmQgaW4gY2xhc3MgQXBwXFNlcnZpY2VcTW92aWVTZXJ2aWNl'));
        $method = $class->getMethod(base64_decode('ZXhwb3J0'));
        $this->assertTrue($method->isPublic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgaXMgbm90IHB1YmxpYy4='));
        $this->assertFalse($method->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgaXMgYWJzdHJhY3Qu'));
        $this->assertFalse($method->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgaXMgZmluYWwu'));
        $this->assertFalse($method->isStatic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgaXMgc3RhdGljLg=='));
        $this->assertEquals(2, $method->getNumberOfRequiredParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgaGFzIGludmFsaWQgbnVtYmVyIG9mIHJlcXVpcmVkIHBhcmFtZXRlcnMu'));
        $this->assertGreaterThanOrEqual(2, $method->getNumberOfParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgaGFzIGludmFsaWQgbnVtYmVyIG9mIHBhcmFtZXRlcnMu'));
        $this->assertSame(base64_decode('c3RyaW5n'), $this->getType($method->getReturnType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgaGFzIGludmFsaWQgcmV0dXJuIHR5cGUu'));
    
        $param0 = $method->getParameters()[0];
        $this->assertSame(base64_decode('c291cmNl'), $param0->getName(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICMwIG9mIG1ldGhvZCBBcHBcU2VydmljZVxNb3ZpZVNlcnZpY2U6OmV4cG9ydCgpIGhhcyBpbnZhbGlkIG5hbWUu'));
        $this->assertSame(base64_decode('QXBwXFNlcnZpY2VcU291cmNl'), $this->getType($param0->getType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRzb3VyY2Ugb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgaGFzIGludmFsaWQgdHlwZS4='));
        $this->assertFalse($param0->allowsNull(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRzb3VyY2Ugb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgYWxsb3dzIG51bGwu'));
    
        $param1 = $method->getParameters()[1];
        $this->assertSame(base64_decode('Zm9ybWF0'), $param1->getName(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICMxIG9mIG1ldGhvZCBBcHBcU2VydmljZVxNb3ZpZVNlcnZpY2U6OmV4cG9ydCgpIGhhcyBpbnZhbGlkIG5hbWUu'));
        $this->assertSame(base64_decode('c3RyaW5n'), $this->getType($param1->getType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRmb3JtYXQgb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgaGFzIGludmFsaWQgdHlwZS4='));
        $this->assertFalse($param1->allowsNull(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRmb3JtYXQgb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXE1vdmllU2VydmljZTo6ZXhwb3J0KCkgYWxsb3dzIG51bGwu'));    

        $this->assertTrue(\interface_exists(base64_decode('QXBwXFNlcnZpY2VcRXhwb3J0')), base64_decode('SW50ZXJmYWNlICdBcHBcU2VydmljZVxFeHBvcnQnIGRvZXMgbm90IGV4aXN0Lg=='));
        $class = new ReflectionClass(base64_decode('QXBwXFNlcnZpY2VcRXhwb3J0'));
        $this->assertTrue($class->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNlcnZpY2VcRXhwb3J0IGlzIG5vdCBhYnN0cmFjdC4='));
        $this->assertFalse($class->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNlcnZpY2VcRXhwb3J0IGlzIGZpbmFsLg=='));

        $this->assertTrue($class->hasMethod(base64_decode('ZXhwb3J0')), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIGV4cG9ydCBub3QgZm91bmQgaW4gY2xhc3MgQXBwXFNlcnZpY2VcRXhwb3J0'));
        $method = $class->getMethod(base64_decode('ZXhwb3J0'));
        $this->assertTrue($method->isPublic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgaXMgbm90IHB1YmxpYy4='));
        $this->assertTrue($method->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgaXMgbm90IGFic3RyYWN0Lg=='));
        $this->assertFalse($method->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgaXMgZmluYWwu'));
        $this->assertFalse($method->isStatic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgaXMgc3RhdGljLg=='));
        $this->assertEquals(2, $method->getNumberOfRequiredParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgaGFzIGludmFsaWQgbnVtYmVyIG9mIHJlcXVpcmVkIHBhcmFtZXRlcnMu'));
        $this->assertGreaterThanOrEqual(2, $method->getNumberOfParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgaGFzIGludmFsaWQgbnVtYmVyIG9mIHBhcmFtZXRlcnMu'));
        $this->assertSame(base64_decode('c3RyaW5n'), $this->getType($method->getReturnType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgaGFzIGludmFsaWQgcmV0dXJuIHR5cGUu'));
    
        $param0 = $method->getParameters()[0];
        $this->assertSame(base64_decode('c291cmNl'), $param0->getName(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICMwIG9mIG1ldGhvZCBBcHBcU2VydmljZVxFeHBvcnQ6OmV4cG9ydCgpIGhhcyBpbnZhbGlkIG5hbWUu'));
        $this->assertSame(base64_decode('QXBwXFNlcnZpY2VcU291cmNl'), $this->getType($param0->getType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRzb3VyY2Ugb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgaGFzIGludmFsaWQgdHlwZS4='));
        $this->assertFalse($param0->allowsNull(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRzb3VyY2Ugb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgYWxsb3dzIG51bGwu'));
    
        $param1 = $method->getParameters()[1];
        $this->assertSame(base64_decode('Zm9ybWF0'), $param1->getName(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICMxIG9mIG1ldGhvZCBBcHBcU2VydmljZVxFeHBvcnQ6OmV4cG9ydCgpIGhhcyBpbnZhbGlkIG5hbWUu'));
        $this->assertSame(base64_decode('c3RyaW5n'), $this->getType($param1->getType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRmb3JtYXQgb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgaGFzIGludmFsaWQgdHlwZS4='));
        $this->assertFalse($param1->allowsNull(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogUGFyYW1ldGVyICRmb3JtYXQgb2YgbWV0aG9kIEFwcFxTZXJ2aWNlXEV4cG9ydDo6ZXhwb3J0KCkgYWxsb3dzIG51bGwu'));    

        $this->assertTrue(\interface_exists(base64_decode('QXBwXFNlcnZpY2VcU291cmNl')), base64_decode('SW50ZXJmYWNlICdBcHBcU2VydmljZVxTb3VyY2UnIGRvZXMgbm90IGV4aXN0Lg=='));
        $class = new ReflectionClass(base64_decode('QXBwXFNlcnZpY2VcU291cmNl'));
        $this->assertTrue($class->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNlcnZpY2VcU291cmNlIGlzIG5vdCBhYnN0cmFjdC4='));
        $this->assertFalse($class->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXFNlcnZpY2VcU291cmNlIGlzIGZpbmFsLg=='));

        $this->assertTrue($class->hasMethod(base64_decode('ZXh0cmFjdA==')), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIGV4dHJhY3Qgbm90IGZvdW5kIGluIGNsYXNzIEFwcFxTZXJ2aWNlXFNvdXJjZQ=='));
        $method = $class->getMethod(base64_decode('ZXh0cmFjdA=='));
        $this->assertTrue($method->isPublic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXFNvdXJjZTo6ZXh0cmFjdCgpIGlzIG5vdCBwdWJsaWMu'));
        $this->assertTrue($method->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXFNvdXJjZTo6ZXh0cmFjdCgpIGlzIG5vdCBhYnN0cmFjdC4='));
        $this->assertFalse($method->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXFNvdXJjZTo6ZXh0cmFjdCgpIGlzIGZpbmFsLg=='));
        $this->assertFalse($method->isStatic(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXFNvdXJjZTo6ZXh0cmFjdCgpIGlzIHN0YXRpYy4='));
        $this->assertEquals(0, $method->getNumberOfRequiredParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXFNvdXJjZTo6ZXh0cmFjdCgpIGhhcyBpbnZhbGlkIG51bWJlciBvZiByZXF1aXJlZCBwYXJhbWV0ZXJzLg=='));
        $this->assertGreaterThanOrEqual(0, $method->getNumberOfParameters(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXFNvdXJjZTo6ZXh0cmFjdCgpIGhhcyBpbnZhbGlkIG51bWJlciBvZiBwYXJhbWV0ZXJzLg=='));
        $this->assertSame(base64_decode('YXJyYXk='), $this->getType($method->getReturnType()), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogTWV0aG9kIEFwcFxTZXJ2aWNlXFNvdXJjZTo6ZXh0cmFjdCgpIGhhcyBpbnZhbGlkIHJldHVybiB0eXBlLg=='));    

        $this->assertTrue(\class_exists(base64_decode('QXBwXEV4Y2VwdGlvblxVbnN1cHBvcnRlZEZvcm1hdEV4Y2VwdGlvbg==')), base64_decode('Q2xhc3MgJ0FwcFxFeGNlcHRpb25cVW5zdXBwb3J0ZWRGb3JtYXRFeGNlcHRpb24nIGRvZXMgbm90IGV4aXN0Lg=='));
        $class = new ReflectionClass(base64_decode('QXBwXEV4Y2VwdGlvblxVbnN1cHBvcnRlZEZvcm1hdEV4Y2VwdGlvbg=='));
        $this->assertFalse($class->isAbstract(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXEV4Y2VwdGlvblxVbnN1cHBvcnRlZEZvcm1hdEV4Y2VwdGlvbiBpcyBhYnN0cmFjdC4='));
        $this->assertFalse($class->isFinal(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXEV4Y2VwdGlvblxVbnN1cHBvcnRlZEZvcm1hdEV4Y2VwdGlvbiBpcyBmaW5hbC4='));
        $this->assertTrue($class->isSubclassOf(base64_decode('RXhjZXB0aW9u')), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXEV4Y2VwdGlvblxVbnN1cHBvcnRlZEZvcm1hdEV4Y2VwdGlvbiBpcyBub3QgYSBzdWJjbGFzcyBvZiBFeGNlcHRpb24u'));
        $this->assertTrue($class->implementsInterface(\Throwable::class), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXEV4Y2VwdGlvblxVbnN1cHBvcnRlZEZvcm1hdEV4Y2VwdGlvbiBkb2VzIG5vdCBpbXBsZW1lbnQgaW50ZXJmYWNlIFRocm93YWJsZS4='));
        $this->assertTrue($class->implementsInterface(\Stringable::class), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXEV4Y2VwdGlvblxVbnN1cHBvcnRlZEZvcm1hdEV4Y2VwdGlvbiBkb2VzIG5vdCBpbXBsZW1lbnQgaW50ZXJmYWNlIFN0cmluZ2FibGUu'));
        $this->assertTrue($class->isInstantiable(), base64_decode('U3RydWN0dXJlIHZpb2xhdGlvbjogQ2xhc3MgQXBwXEV4Y2VwdGlvblxVbnN1cHBvcnRlZEZvcm1hdEV4Y2VwdGlvbiBpcyBub3QgaW5zdGFudGlhYmxlLg=='));
    }

    protected function getType(?ReflectionType $type): ?string
    {
        if (!$type) {
            return null;
        }

        // Function ReflectionType::__toString() is deprecated in PHP 7.x. But it's no longer the case for PHP 8.
        if (version_compare(PHP_VERSION, '8.0', '<')) {
            /** @noinspection PhpPossiblePolymorphicInvocationInspection */
            /** @var \ReflectionNamedType $type */
            return $type->getName() . ($type->allowsNull() ? '|null' : '');
        }

        $typeStr = (string) $type;

        // PHP 8.0 represents nullable types with ? prefix (except mixed, because ?mixed is syntactically invalid).
        // In PHP 8.1 the existing ?T notation is considered a shorthand for the common case of T|null.
        if (substr($typeStr, 0, 1) === '?') {
            $typeStr = substr($typeStr, 1) . '|null';
        }

        return $typeStr;
    }
}
