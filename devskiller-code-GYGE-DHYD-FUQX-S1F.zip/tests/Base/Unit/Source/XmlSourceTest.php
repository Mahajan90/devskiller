<?php

declare(strict_types=1);

namespace App\Tests\Base\Source;

use App\Service\Source;
use App\Source\XmlSource;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

class XmlSourceTest extends TestCase
{
    private const FILE_PATH       = __DIR__ . '/../../movies.xml';
    private const FILE_PATH_EMPTY = __DIR__ . '/../../movies-empty.xml';

    /**
     * @test
     */
    public function it_extracts_data_from_xml_format(): void
    {
        $xmlSource = new XmlSource(self::FILE_PATH);

        $expected = [
            'movies' => [
                [
                    'title'    => 'Pulp Fiction',
                    'year'     => '1994',
                    'director' => 'Quentin Tarantino',
                    'actors' => [
                        'John Travolta',
                        'Samuel L. Jackson',
                        'Uma Thurman'
                    ]
                ],
                [
                    'title'    => 'Equilibrium',
                    'year'     => '2002',
                    'director' => 'Kurt Wimmer',
                    'actors'   => [
                        'Christian Bale',
                        'Emily Watson',
                        'Taye Diggs'
                    ]
                ],
                [
                    'title'    => 'The Green Mile',
                    'year'     => '1999',
                    'director' => 'Frank Darabont',
                    'actors'   => [
                        'Tom Hanks',
                        'David Morse',
                        'Bonnie Hunt'
                    ]
                ],
            ]
        ];

        $this->assertSame($expected, $xmlSource->extract());
    }

    /**
     * @test
     */
    public function it_extracts_empty_data_from_xml_format(): void
    {
        $xmlSource = new XmlSource(self::FILE_PATH_EMPTY);

        $expected = ['movies' => []];

        $this->assertSame($expected, $xmlSource->extract());
    }

    /**
     * @test
     */
    public function it_implements_source_interface(): void
    {
        $xmlSource = new XmlSource(self::FILE_PATH);

        $this->assertInstanceOf(Source::class, $xmlSource);
    }
}
