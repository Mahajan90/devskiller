<?php

declare(strict_types=1);

namespace App\Tests\Base\Service;

use App\Service\Source;
use App\Service\Export;
use App\Service\MovieService;
use PHPUnit\Framework\TestCase;
use App\Exception\UnsupportedFormatException;

class MovieServiceTest extends TestCase
{
    /**
     * @test
     */
    public function it_exports_movies_to_csv_with_default_separator(): void
    {
        $movieService = new MovieService();

        $sourceMock = $this->createMock(Source::class);
        $sourceMock->method('extract')->willReturn([
            'movies' => [
                [
                    'title'    => 'Pulp Fiction',
                    'year'     => '1994',
                    'director' => 'Quentin Tarantino',
                    'actors' => [
                        'John Travolta',
                        'Samuel L. Jackson',
                        'Uma Thurman'
                    ]
                ],
                [
                    'title'    => 'Equilibrium',
                    'year'     => '2002',
                    'director' => 'Kurt Wimmer',
                    'actors'   => [
                        'Christian Bale',
                        'Emily Watson',
                        'Taye Diggs'
                    ]
                ],
                [
                    'title'    => 'The Green Mile',
                    'year'     => '1999',
                    'director' => 'Frank Darabont',
                    'actors'   => [
                        'Tom Hanks',
                        'David Morse',
                        'Bonnie Hunt'
                    ]
                ],
            ]
        ]);

        $expected = "\"Pulp Fiction\",1994,\"Quentin Tarantino\",\"John Travolta, Samuel L. Jackson, Uma Thurman\"\n";
        $expected .= "Equilibrium,2002,\"Kurt Wimmer\",\"Christian Bale, Emily Watson, Taye Diggs\"\n";
        $expected .= "\"The Green Mile\",1999,\"Frank Darabont\",\"Tom Hanks, David Morse, Bonnie Hunt\"\n";

        $this->assertSame(
            $movieService->export($sourceMock, 'csv'),
            $expected,
        );
    }

    /**
     * @test
     */
    public function it_exports_movies_to_csv_with_semicolon_separator(): void
    {
        $movieService = new MovieService(';');

        $sourceMock = $this->createMock(Source::class);
        $sourceMock->method('extract')->willReturn([
            'movies' => [
                [
                    'title'    => 'Pulp Fiction',
                    'year'     => '1994',
                    'director' => 'Quentin Tarantino',
                    'actors' => [
                        'John Travolta',
                        'Samuel L. Jackson',
                        'Uma Thurman'
                    ]
                ],
                [
                    'title'    => 'Equilibrium',
                    'year'     => '2002',
                    'director' => 'Kurt Wimmer',
                    'actors'   => [
                        'Christian Bale',
                        'Emily Watson',
                        'Taye Diggs'
                    ]
                ],
                [
                    'title'    => 'The Green Mile',
                    'year'     => '1999',
                    'director' => 'Frank Darabont',
                    'actors'   => [
                        'Tom Hanks',
                        'David Morse',
                        'Bonnie Hunt'
                    ]
                ],
            ]
        ]);

        $expected = "\"Pulp Fiction\";1994;\"Quentin Tarantino\";\"John Travolta, Samuel L. Jackson, Uma Thurman\"\n";
        $expected .= "Equilibrium;2002;\"Kurt Wimmer\";\"Christian Bale, Emily Watson, Taye Diggs\"\n";
        $expected .= "\"The Green Mile\";1999;\"Frank Darabont\";\"Tom Hanks, David Morse, Bonnie Hunt\"\n";

        $this->assertSame(
            $movieService->export($sourceMock, 'csv'),
            $expected,
        );
    }

    /**
     * @test
     */
    public function it_implements_export_interface(): void
    {
        $movieService = new MovieService();

        $this->assertInstanceOf(Export::class, $movieService);
    }

    /**
     * @test
     */
    public function it_throws_unsupported_format_exception(): void
    {
        $this->expectException(UnsupportedFormatException::class);
        $this->expectExceptionMessage('Format json is not supported.');

        $movieService = new MovieService();
        $sourceMock = $this->createMock(Source::class);

        $movieService->export($sourceMock, 'json');
    }
}
