<?php

declare(strict_types=1);

namespace App\Tests\Base\Functional;

use App\Service\Source;
use App\Service\Export;
use App\Source\XmlSource;
use App\Service\MovieService;
use PHPUnit\Framework\TestCase;

class MovieServiceTest extends TestCase
{
    /**
     * @test
     */
    public function it_exports_movies_to_csv_from_xml_source(): void
    {
        $xmlSource = new XmlSource(__DIR__ . '/../movies.xml');
        $movieService = new MovieService();

        $expected = "\"Pulp Fiction\",1994,\"Quentin Tarantino\",\"John Travolta, Samuel L. Jackson, Uma Thurman\"\n";
        $expected .= "Equilibrium,2002,\"Kurt Wimmer\",\"Christian Bale, Emily Watson, Taye Diggs\"\n";
        $expected .= "\"The Green Mile\",1999,\"Frank Darabont\",\"Tom Hanks, David Morse, Bonnie Hunt\"\n";

        $this->assertSame(
            $movieService->export($xmlSource, 'csv'),
            $expected,
        );
    }
}
