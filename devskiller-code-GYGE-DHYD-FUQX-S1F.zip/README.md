# Introduction
You are working on functionality for a movie store that converts data from XML to CSV format. 

# Task definition
To complete this task, you should:

* Implement `\App\Source\XmlSource`
  * It extracts movies data from an XML file into an array.

* Implement `\App\Service\MovieService`
  * It converts data into many formats. Currently, we want to support only CSV format.

If You want to familiarize yourself with the structure of the method output let's look in the `/tests` directory for more implementation details.

# Example

#### Sample XML file:

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<movies>
    <movie>
        <title>Arrival</title>
        <year>2016</year>
        <director>Denis Villeneuve</director>
        <actors>
            <actor>
                <name>Amy Adams</name>
            </actor>
            <actor>
                <name>Jeremy Renner</name>
            </actor>
            <actor>
                <name>Forest Whitaker</name>
            </actor>
        </actors>
    </movie>
    <movie>
        <title>Get Out</title>
        <year>2017</year>
        <director>Jordan Peele</director>
        <actors>
            <actor>
                <name>Daniel Kaluuya</name>
            </actor>
            <actor>
                <name>Allison Williams</name>
            </actor>
            <actor>
                <name>Catherine Keener</name>
            </actor>
        </actors>
    </movie>
</movies>
```

#### Sample call of code:

```php
$movieService = new MovieService();

$xmlSource = new XmlSource('movies.xml');

$csv = $movieService->export($xmlSource, 'csv');

file_put_contents('movies.csv', $csv);
```

# Hints
- To read an XML file you can use SimpleXML extension (https://www.php.net/manual/en/book.simplexml.php).

# How to run
```shell script
$ composer install
$ composer test
```

